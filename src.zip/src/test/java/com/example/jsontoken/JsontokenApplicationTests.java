package com.example.jsontoken;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsontokenApplicationTests {

	@Test
	void contextLoads() {
	}

}
