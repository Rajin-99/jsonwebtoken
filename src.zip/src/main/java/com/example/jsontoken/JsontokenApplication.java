package com.example.jsontoken;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsontokenApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsontokenApplication.class, args);
	}

}
